module.exports = {
modul: {
	axios: require('axios'),
	boom: require('@hapi/boom'),
	baileys: require("@whiskeysockets/baileys"),
	chalk: require('chalk'),
	crypto: require('crypto'),
	child_process: require('child_process'),
	fs: require('fs'),
	fetch: require('node-fetch'),
	figlet: require('figlet'),
	human: require('human-readable'),
	keyeddb: require('@adiwajshing/keyed-db'),
	lodash: require('lodash'),
	moment: require('moment-timezone'),
	ms: require('ms'),
	os: require('os'),
	path: require('path'),
	perf_hooks: require('perf_hooks'),
	pino: require('pino'),
	process: require('process'),
    speed: require('performance-now'),
    stream: require('stream'),

}
}

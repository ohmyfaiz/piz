/*

Minimal kasih credits DitchieMods

*/


const fs = require('fs')

global.botname = "ZetsuChie-X"
global.version = "0.0.0"
global.owner = "6283129068746"
global.numberbot = "6283177187092"
global.footer = "𝑫͢𝒊𝒕͠𝒄𝒉͜͡𝒊𝒆͎𝑴͢𝒐͡𝒅𝒔"
global.title = "© 𝑫͢𝒊𝒕͠𝒄𝒉͜͡𝒊𝒆͎𝑴͢𝒐͡𝒅𝒔"
global.website = "https://whatsapp.com/channel/0029Vb4g6DmKmCPJVRjvG52K"
global.idch = "120363380926092343@newsletter"
global.chjid = "https://whatsapp.com/channel/0029Vb4g6DmKmCPJVRjvG52K"
global.wm = "𝑫͢𝒊𝒕͠𝒄𝒉͜͡𝒊𝒆͎𝑴͢𝒐͡𝒅𝒔"
//===================================//
global.session = "session"

//=========== [ DLAY-PUSH ] ===========//
global.delaypushv1 = 7000 // 1000-1DETIK
global.delaypushv2 = 7000 // 1000-1DETIK

//=========== [ IMG-URL ] ===========//
global.thumb = "https://files.catbox.moe/siauf3.jpg"
global.image = {
Reply: "https://files.catbox.moe/siauf3.jpg"
}
//==================================//

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})


global.owner = ["6285823103767","62895323931022"]

global.namaowner = '𝗠𝗜𝗞𝗨 𝗗𝗘𝗩'
global.idsaluran = '120363399106257546@newsletter'
global.linkgc = '-'

let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})
